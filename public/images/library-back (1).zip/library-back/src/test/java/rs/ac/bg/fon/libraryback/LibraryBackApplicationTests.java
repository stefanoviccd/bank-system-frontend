package rs.ac.bg.fon.libraryback;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryBackApplicationTests {

	@Test
	void contextLoads() {
	}

}
