package model;

public class MyMath {
    private int a;
    private int b;
    private int c;
    private String operation;

    public MyMath() {
    }

    public MyMath(int a, int b, int c) {
        this.a = a;
        this.b = b;
        this.c = c;
        operation = "Nije definisana";
    }

    public String getOperation() {
        return operation;
    }

    public void setOperation(String operation) {
        this.operation = operation;
    }

    
    public int getA() {
        return a;
    }

    public void setA(int a) {
        this.a = a;
    }

    public int getB() {
        return b;
    }

    public void setB(int b) {
        this.b = b;
    }

    public int getC() {
        return c;
    }

    public void setC(int c) {
        this.c = c;
    }
    
    
}
